package com.example.CirculAPP

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.outlined.ContactPage
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.CirculAPP.ui.customFont
import com.example.CirculAPP.ui.IconWithLabel
import kotlinx.coroutines.delay

@Composable
fun MotoristaOptionsScreen(navController: NavController) {
    var showSobreNosDialog by remember { mutableStateOf(false) }
    var showContatosDialog by remember { mutableStateOf(false) }

    var animarImagem by remember { mutableStateOf(false) }
    var animarTextos by remember { mutableStateOf(false) }
    var animarConteudoBotoes by remember { mutableStateOf(false) }
    var animarBotaoSair by remember { mutableStateOf(false) }
    var animarIconesTopo by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        delay(50)
        animarImagem = true
        delay(200)
        animarTextos = true
        delay(150)
        animarIconesTopo = true
        delay(250)
        animarConteudoBotoes = true
        delay(100)
        animarBotaoSair = true
    }

    val screenHeight = LocalConfiguration.current.screenHeightDp.dp
    val density = LocalDensity.current
    val offsetY = with(density) { (screenHeight * 0.575f).roundToPx() }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {

            // --- PARTE AZUL (65%) ---
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.65f)
                    .background(Color(0xFF004AAD))
                    .padding(horizontal = 16.dp, vertical = 24.dp)
            ) {
                androidx.compose.animation.AnimatedVisibility(
                    visible = animarIconesTopo,
                    enter = fadeIn(tween(1200)),
                    modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter).padding(top = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        IconWithLabel(Icons.Outlined.ContactPage, "Sobre nós") { showSobreNosDialog = true }
                        IconWithLabel(Icons.Outlined.Phone, "Contatos") { showContatosDialog = true }
                    }
                }

                Column(modifier = Modifier.fillMaxSize().padding(top = 65.dp)) {
                    androidx.compose.animation.AnimatedVisibility(
                        visible = animarImagem,
                        enter = fadeIn(tween(1500)) + scaleIn(initialScale = 0.92f)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.imagem_motorista),
                            contentDescription = null,
                            modifier = Modifier.fillMaxWidth().height(180.dp)
                        )
                    }

                    androidx.compose.animation.AnimatedVisibility(
                        visible = animarTextos,
                        enter = fadeIn(tween(1200)) + slideInVertically { it / 3 }
                    ) {
                        Column {
                            Text(text = "\nBem-vindo", fontSize = 24.sp, fontFamily = customFont, fontWeight = FontWeight.Bold, color = Color.White)
                            HorizontalDivider(color = Color.White, thickness = 2.dp, modifier = Modifier.fillMaxWidth(0.76f).padding(vertical = 16.dp))
                            Text(text = "Selecione uma das opções abaixo para iniciar rota ou informar uma parada", color = Color.White, fontSize = 16.sp, fontFamily = customFont)
                        }
                    }
                }
            }

            // --- PARTE BRANCA (35%) ---
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.35f)
                    .background(Color.White),
                contentAlignment = Alignment.BottomCenter
            ) {
                androidx.compose.animation.AnimatedVisibility(
                    visible = animarBotaoSair,
                    enter = fadeIn(tween(1000)) + slideInVertically { 40 },
                    modifier = Modifier.padding(bottom = 110.dp)
                ) {
                    Surface(
                        onClick = { navController.navigate("userSelection") },
                        modifier = Modifier.height(48.dp).fillMaxWidth(0.65f),
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFE0E0E0),
                        shadowElevation = 2.dp
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxSize()) {
                            Box(
                                modifier = Modifier.fillMaxHeight().width(40.dp).background(Color(0xFFFFD700)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Filled.ExitToApp, contentDescription = null, tint = Color(0xFF004AAD), modifier = Modifier.size(20.dp))
                            }
                            Text(
                                text = "Sair",
                                color = Color(0xFF004AAD),
                                fontSize = 14.sp,
                                fontFamily = customFont,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }

        // --- BOTÕES CENTRAIS (POSICIONADOS NO MEIO) ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(screenHeight * 0.08f)
                .offset { IntOffset(0, offsetY) }
                .background(Color(0xFF004AAD))
        ) {
            Button(
                onClick = { navController.navigate("iniciarRota") },
                modifier = Modifier.weight(1f).fillMaxHeight(),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                shape = RoundedCornerShape(0.dp)
            ) {
                Text("Iniciar Rota", fontFamily = customFont, color = Color.White, fontSize = 16.sp, modifier = Modifier.alpha(if (animarConteudoBotoes) 1f else 0f))
            }

            Box(modifier = Modifier.width(2.dp).fillMaxHeight().background(if (animarConteudoBotoes) Color.White else Color.Transparent))

            Button(
                onClick = { navController.navigate("informarParada") },
                modifier = Modifier.weight(1f).fillMaxHeight(),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                shape = RoundedCornerShape(0.dp)
            ) {
                Text("Informar Parada", fontFamily = customFont, color = Color.White, fontSize = 16.sp, modifier = Modifier.alpha(if (animarConteudoBotoes) 1f else 0f))
            }
        }
    }

        // --- Diálogos (Mantidos) ---
        if (showSobreNosDialog) {
            AlertDialog(
                onDismissRequest = { showSobreNosDialog = false },
                confirmButton = {
                    TextButton(onClick = {
                        showSobreNosDialog = false
                    }) { Text("Fechar", fontFamily = customFont) }
                },
                title = { Text("Sobre o CirculAPP", fontSize = 24.sp) },
                text = {
                    Text(
                        fontSize = 14.sp,
                        fontFamily = com.example.CirculAPP.ui.customFont,
                        text = "Este aplicativo foi desenvolvido com dedicação por Emanuel Barbosa e Matheus, estudantes da Universidade Federal Rural de Pernambuco (UFRPE), com o objetivo de facilitar a mobilidade no campus e fortalecer a comunicação entre alunos e motoristas. 🎓\n\n" +
                                "👨‍💻 Desenvolvedores\n" +
                                "• Emanuel Barbosa\n" +
                                "\t📸 Instagram: @EmanuelB87_\n" +
                                "\t💻 GitHub: Emanuel-dev-Silva\n\n"
                    )
                }
            )
        }
        if (showContatosDialog) {
            AlertDialog(
                onDismissRequest = { showContatosDialog = false },
                confirmButton = {
                    TextButton(onClick = {
                        showContatosDialog = false
                    }) { Text("Fechar", fontFamily = customFont) }
                },
                title = { Text("DELOGS/UFRPE", fontSize = 24.sp) },
                text = {
                    Text(
                        text = """
📍 DELOGS – Departamento de Logística e Serviços
• Diretoria: diretoria.delogs@ufrpe.br
• Resíduos laboratoriais: davv.delogs@ufrpe.br
• Segurança Universitária (DSU): seguranca.delogs@ufrpe.br
• Instagram: @ufrpedelogs

📍 Outros Setores da UFRPE
• Ouvidoria: ouvidoria@ufrpe.br
• Comunicação (Ascom): comunicacao@ufrpe.br
• Secretaria Geral: secretaria.geral@ufrpe.br
• Tecnologia da Informação (STI): sti@ufrpe.br
• Instagram oficial: @ufrpeoficial
""".trimIndent(),
                        fontSize = 14.sp,
                        fontFamily = customFont,
                        color = Color.Black,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            )
        }
    }
