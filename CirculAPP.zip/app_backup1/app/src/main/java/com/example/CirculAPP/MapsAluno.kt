package com.example.CirculAPP

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.example.CirculAPP.databinding.ActivityMapsBinding
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.*
import com.google.firebase.database.*
import java.util.Calendar

class MapsAluno : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding
    private val database = FirebaseDatabase.getInstance()
    private val motoristaRef = database.getReference("motorista/localizacao")
    private var motoristaMarker: Marker? = null
    private var motoristaLocation: LatLng? = null
    private var isPositionLocked = false
    private var currentZoomLevel = 16f
    private val handler = Handler(Looper.getMainLooper())
    private val updateInterval: Long = 30000

    private val CHANNEL_ID = "circulapp_notifications"
    private val prefs by lazy { getSharedPreferences("app_prefs", Context.MODE_PRIVATE) }

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            Toast.makeText(this, "Permissão concedida!", Toast.LENGTH_SHORT).show()
        }
    }

    override fun attachBaseContext(newBase: Context) {
        val newConfig = Configuration(newBase.resources.configuration)
        newConfig.fontScale = 1.0f
        val context = newBase.createConfigurationContext(newConfig)
        super.attachBaseContext(context)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        checkNotificationPermission()
        createNotificationChannel()

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val sharedPreferences = getSharedPreferences("UserSettings", MODE_PRIVATE)
        currentZoomLevel = sharedPreferences.getFloat("zoomLevel", 16f)

        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as? SupportMapFragment
        mapFragment?.getMapAsync(this)

        // CONFIGURAÇÃO DO SWITCH (LIGA/DESLIGA O SERVIÇO EXTERNO)
        val checkBoxNotification = findViewById<androidx.appcompat.widget.SwitchCompat>(R.id.checkBoxNotification)

        // Sincroniza o switch com o que está salvo
        val notificacaoAtivada = prefs.getBoolean("notificacaoAtivada", false)
        checkBoxNotification.isChecked = notificacaoAtivada

        checkBoxNotification.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("notificacaoAtivada", isChecked).apply()

            val intentService = Intent(this, NotificationService::class.java)

            if (isChecked) {
                // Inicia o "Vigia" (Funciona com app fechado)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(intentService)
                } else {
                    startService(intentService)
                }
                Toast.makeText(this, "Notificações ativadas!", Toast.LENGTH_SHORT).show()
            } else {
                // Mata o "Vigia" imediatamente
                stopService(intentService)
                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.cancelAll()
                Toast.makeText(this, "Notificações desativadas!", Toast.LENGTH_SHORT).show()
            }
        }

        motoristaRef.keepSynced(true)
        listenMotoristaLocation()

        findViewById<Button>(R.id.btnVoltar).setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        findViewById<Button>(R.id.btnCentralizarCircular).setOnClickListener {
            motoristaLocation?.let {
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(it, currentZoomLevel))
            }
        }

        findViewById<Button>(R.id.btnTravarPosicao).setOnClickListener {
            isPositionLocked = !isPositionLocked
            Toast.makeText(this, if (isPositionLocked) "Posição Travada" else "Posição Livre", Toast.LENGTH_SHORT).show()
        }

        startUpdating()
    }

    private fun checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Notificações Circular"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 200, 500)
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun startUpdating() {
        handler.postDelayed(object : Runnable {
            override fun run() {
                listenMotoristaLocation()
                handler.postDelayed(this, updateInterval)
            }
        }, updateInterval)
    }

    private fun listenMotoristaLocation() {
        motoristaRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val now = Calendar.getInstance()
                val totalMinutos = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
                val limiteInicio = 6 * 60 + 40
                val limiteFim = 22 * 60 + 20

                if (totalMinutos in limiteInicio..limiteFim) {
                    val latitude = snapshot.child("latitude").getValue(Double::class.java)
                    val longitude = snapshot.child("longitude").getValue(Double::class.java)
                    val status = snapshot.child("status").getValue(String::class.java) ?: "Indisponível"
                    val parada = snapshot.child("parada").getValue(String::class.java)?.trim() ?: ""
                    val rota = snapshot.child("rota").getValue(String::class.java) ?: "Não definida"

                    runOnUiThread {
                        findViewById<LinearLayout>(R.id.mensagemContainer).visibility = android.view.View.VISIBLE
                        val mensagemTexto = findViewById<TextView>(R.id.mensagemTexto)

                        when (status) {
                            "indisponível", "inativa" -> {
                                motoristaMarker?.remove()
                                motoristaMarker = null
                                mensagemTexto.text = "❌ Circular indisponível ❌"
                            }
                            "parado" -> {
                                mensagemTexto.text = "🛑 Parado: $parada"
                            }
                            "em rota" -> {
                                if (latitude != null && longitude != null) {
                                    motoristaLocation = LatLng(latitude, longitude)
                                    motoristaMarker?.remove()
                                    motoristaMarker = mMap.addMarker(MarkerOptions()
                                        .position(motoristaLocation!!)
                                        .icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_motorista)))

                                    if (!isPositionLocked) {
                                        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(motoristaLocation!!, currentZoomLevel))
                                    }
                                    mensagemTexto.text = "🚍 Em rota: $rota"
                                }
                            }
                        }
                    }
                } else {
                    runOnUiThread {
                        findViewById<TextView>(R.id.mensagemTexto).text = "🕒 Fora do horário"
                    }
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        val ufrpe = LatLng(-8.017335662754297, -34.949115979298256)
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(ufrpe, currentZoomLevel))
        try { mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(this, R.raw.estilo_maps)) } catch (e: Exception) {}
        addFixedMarkers()
    }

    private fun addFixedMarkers() {
        val locais = listOf(
            LatLng(-8.018405587113017, -34.95003668228588) to "Cegoe",
            LatLng(-8.015908378317642, -34.950759580760014) to "Guarita Piscina",
            LatLng(-8.014528748288745, -34.95043753092098) to "Reitoria",
            LatLng(-8.01621201175587, -34.94950232571275) to "Biblioteca Setorial",
            LatLng(-8.017728749495607, -34.94478152968631) to "Ceagri Computação",
            LatLng(-8.020046094447412, -34.95411159356041) to "Zootecnia",
            LatLng(-8.015024, -34.947718) to "Veterinária",
            LatLng(-8.014025, -34.948765) to "Biblioteca Central"
        )
        locais.forEach { (posicao, titulo) ->
            val originalBitmap = BitmapFactory.decodeResource(resources, R.drawable.icone_parada)
            val resizedIcon = Bitmap.createScaledBitmap(originalBitmap, 155, 155, false)
            mMap.addMarker(MarkerOptions().position(posicao).title(titulo).icon(BitmapDescriptorFactory.fromBitmap(resizedIcon)))
        }
    }
}