package com.example.CirculAPP.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardDoubleArrowUp
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.CirculAPP.R
import kotlinx.coroutines.delay

private val localCustomFont = FontFamily(Font(R.font.sam_font1))

// Paleta de Cores UFRPE
private val UFRPE_Blue = Color(0xFF004AAD)
private val UFRPE_Yellow = Color(0xFFFFD700)
// Cinza atualizado para maior contraste
private val Light_Gray_Darker = Color(0xFFE0E0E0)

@Composable
fun AlunoIconWithLabel(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .padding(top = 8.dp)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(imageVector = icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(28.dp))
        Text(text = label, color = Color.White, fontSize = 12.sp, textAlign = TextAlign.Center, fontFamily = localCustomFont)
    }
}

@Composable
fun AlunoScreen(
    navController: NavController,
    onAcessarMapa: () -> Unit
) {
    var selectedOption by remember { mutableStateOf("Aluno") }
    var showSobreNosDialog by remember { mutableStateOf(false) }
    var showContatosDialog by remember { mutableStateOf(false) }

    var animarImagem by remember { mutableStateOf(false) }
    var animarTextos by remember { mutableStateOf(false) }
    var animarBotoes by remember { mutableStateOf(false) }
    var animarIconesTopo by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        delay(50)
        animarImagem = true
        delay(200)
        animarTextos = true
        delay(150)
        animarIconesTopo = true
        delay(300)
        animarBotoes = true
    }

    val screenHeight = LocalConfiguration.current.screenHeightDp.dp
    val density = LocalDensity.current
    val offsetY = with(density) { (screenHeight * 0.575f).roundToPx() }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {

            // Parte Azul (65%)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.65f)
                    .background(UFRPE_Blue)
                    .padding(horizontal = 16.dp, vertical = 24.dp),
            ) {
                androidx.compose.animation.AnimatedVisibility(
                    visible = animarIconesTopo,
                    enter = fadeIn(tween(1200)),
                    modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter).padding(top = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        AlunoIconWithLabel(Icons.Outlined.ContactPage, "Sobre nós") { showSobreNosDialog = true }
                        AlunoIconWithLabel(Icons.Outlined.Phone, "Contatos") { showContatosDialog = true }
                    }
                }

                Column(
                    modifier = Modifier.fillMaxSize().padding(top = 65.dp),
                    verticalArrangement = Arrangement.Top
                ) {
                    androidx.compose.animation.AnimatedVisibility(
                        visible = animarImagem,
                        enter = fadeIn(tween(1500)) + scaleIn(initialScale = 0.9f, animationSpec = tween(1500))
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.imagem_aluno),
                            contentDescription = null,
                            modifier = Modifier.fillMaxWidth().height(200.dp)
                        )
                    }

                    androidx.compose.animation.AnimatedVisibility(
                        visible = animarTextos,
                        enter = fadeIn(tween(1200)) + slideInVertically(tween(1200)) { it / 3 }
                    ) {
                        Column {
                            Text(text = "Bem-vindo", fontSize = 24.sp, fontFamily = localCustomFont, color = Color.White)
                            HorizontalDivider(color = UFRPE_Yellow, thickness = 2.dp, modifier = Modifier.fillMaxWidth(0.76f).padding(vertical = 12.dp))
                            Text(text = "Selecione uma opção para navegar no campus", fontSize = 16.sp, color = Color.White, fontFamily = localCustomFont)
                        }
                    }
                }
            }

            // Parte Branca (35%)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.35f)
                    .background(Color.White)
            ) {
                androidx.compose.animation.AnimatedVisibility(
                    visible = animarBotoes,
                    enter = fadeIn(tween(1200)) + slideInVertically(tween(1000)) { 20 },
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(start = 28.dp, top = 45.dp, end = 28.dp, bottom = 15.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // 1. Botão Acessar Mapa ESTILO PREMIUM (Cinza Escurecido)
                        Surface(
                            onClick = { onAcessarMapa() },
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            color = Light_Gray_Darker,
                            shape = RoundedCornerShape(12.dp),
                            shadowElevation = 4.dp
                        ) {
                            Row(
                                modifier = Modifier.fillMaxSize(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .width(52.dp)
                                        .background(UFRPE_Yellow),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Filled.KeyboardDoubleArrowUp,
                                        contentDescription = null,
                                        tint = UFRPE_Blue,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Text(
                                    text = "Acessar Mapa",
                                    modifier = Modifier.weight(0.85f),
                                    textAlign = TextAlign.Center,
                                    color = UFRPE_Blue,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = localCustomFont,
                                    fontSize = 18.sp
                                )
                            }
                        }

                        // 2. Cards Centrais (Itinerário e Horários)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            CardOption(
                                icon = Icons.Outlined.Map,
                                label = "Itinerário",
                                modifier = Modifier.weight(1f).height(80.dp),
                                onClick = { navController.navigate("itinerario") }
                            )
                            CardOption(
                                icon = Icons.Outlined.Schedule,
                                label = "Horários",
                                modifier = Modifier.weight(1f).height(80.dp),
                                onClick = { navController.navigate("horarios") }
                            )
                        }

                        // 3. Botão Voltar (Estilo discreto)
                        TextButton(
                            onClick = { navController.navigate("userSelection") },
                            modifier = Modifier.height(40.dp)
                        ) {
                            Icon(Icons.Outlined.ArrowBackIosNew, null, modifier = Modifier.size(14.dp), tint = UFRPE_Blue)
                            Spacer(Modifier.width(8.dp))
                            Text("Voltar", color = UFRPE_Blue, fontSize = 15.sp, fontFamily = localCustomFont)
                        }
                    }
                }
            }
        }

        // BARRA CENTRAL ESTÁTICA
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(screenHeight * 0.08f)
                .offset { IntOffset(0, offsetY) }
                .background(UFRPE_Blue)
        ) {
            Button(
                onClick = { selectedOption = "Aluno" },
                modifier = Modifier.weight(1f).fillMaxHeight(),
                colors = ButtonDefaults.buttonColors(containerColor = if (selectedOption == "Aluno") Light_Gray_Darker else Color.Transparent),
                shape = RoundedCornerShape(0.dp)
            ) {
                Text("Aluno", color = if (selectedOption == "Aluno") UFRPE_Blue else Color.White, fontFamily = localCustomFont)
            }
            Box(Modifier.width(1.dp).fillMaxHeight().background(Color.White.copy(alpha = 0.5f)))
            Button(
                onClick = {
                    selectedOption = "Motorista"
                    navController.navigate("motoristaLogin")
                },
                modifier = Modifier.weight(1f).fillMaxHeight(),
                colors = ButtonDefaults.buttonColors(containerColor = if (selectedOption == "Motorista") Light_Gray_Darker else Color.Transparent),
                shape = RoundedCornerShape(0.dp)
            ) {
                Text("Motorista", color = if (selectedOption == "Motorista") UFRPE_Blue else Color.White, fontFamily = localCustomFont)
            }
        }
    }

    // Diálogos (Permanecem iguais)
    if (showSobreNosDialog) {
        AlertDialog(
            onDismissRequest = { showSobreNosDialog = false },
            confirmButton = { TextButton(onClick = { showSobreNosDialog = false }) { Text("Fechar") } },
            title = { Text("Sobre") },
            text = { Text(
                fontSize = 14.sp,
                fontFamily = com.example.CirculAPP.ui.customFont,
                text = "Este aplicativo foi desenvolvido com dedicação por Emanuel Barbosa e Matheus, estudantes da Universidade Federal Rural de Pernambuco (UFRPE), com o objetivo de facilitar a mobilidade no campus e fortalecer a comunicação entre alunos e motoristas. 🎓\n\n" +
                        "👨‍💻 Desenvolvedores\n" +
                        "• Emanuel Barbosa\n" +
                        "\t📸 Instagram: @EmanuelB87_\n" +
                        "\t💻 GitHub: Emanuel-dev-Silva\n\n" ) }
        )
    }

    if (showContatosDialog) {
        AlertDialog(
            onDismissRequest = { showContatosDialog = false },
            confirmButton = { TextButton(onClick = { showContatosDialog = false }) { Text("Fechar") } },
            title = { Text("Contatos") },
            text = { Text(
                text = """
📍 DELOGS – Departamento de Logística e Serviços
• Diretoria: diretoria.delogs@ufrpe.br
• Resíduos laboratoriais: davv.delogs@ufrpe.br
• Segurança Universitária (DSU): seguranca.delogs@ufrpe.br
• Instagram: @ufrpedelogs

📍 Outros Setores da UFRPE
• Ouvidoria: ouvidoria@ufrpe.br
• Comunicação (Ascom): comunicacao@ufrpe.br
• Secretaria Geral: secretaria.geral@ufrpe.br
• Tecnologia da Informação (STI): sti@ufrpe.br
• Instagram oficial: @ufrpeoficial
""".trimIndent(),
                fontSize = 14.sp,
                fontFamily = customFont,
                color = Color.Black,
                modifier = Modifier.fillMaxWidth()
            ) }
        )
    }
}

@Composable
fun CardOption(icon: ImageVector, label: String, modifier: Modifier, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        modifier = modifier,
        color = Light_Gray_Darker,
        shape = RoundedCornerShape(12.dp),
        shadowElevation = 2.dp
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(icon, contentDescription = null, tint = UFRPE_Blue, modifier = Modifier.size(26.dp))
            Spacer(Modifier.height(6.dp))
            Box(Modifier.width(24.dp).height(2.dp).background(UFRPE_Yellow))
            Spacer(Modifier.height(6.dp))
            Text(label, color = UFRPE_Blue, fontSize = 14.sp, fontFamily = localCustomFont)
        }
    }
}