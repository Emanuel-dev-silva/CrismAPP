package com.example.CirculAPP.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.CirculAPP.R
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ktx.getValue
import kotlinx.coroutines.delay

// Padronização de Cores
private val UFRPE_Blue = Color(0xFF004AAD)
private val UFRPE_Yellow = Color(0xFFFFD700)
private val Light_Gray_Darker = Color(0xFFE0E0E0)

@Composable
fun LoginIconWithLabel(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .padding(top = 8.dp)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(imageVector = icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(28.dp))
        Text(text = label, color = Color.White, fontSize = 12.sp, textAlign = TextAlign.Center, fontFamily = customFont)
    }
}

@Composable
fun LoginScreen(navController: NavController) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var lembrarSenha by remember { mutableStateOf(false) }
    var loginError by remember { mutableStateOf(false) }
    var selectedOption by remember { mutableStateOf("Motorista") }

    var showSobreNosDialog by remember { mutableStateOf(false) }
    var showContatosDialog by remember { mutableStateOf(false) }

    var animarImagem by remember { mutableStateOf(false) }
    var animarTextos by remember { mutableStateOf(false) }
    var animarCampos by remember { mutableStateOf(false) }
    var animarIconesTopo by remember { mutableStateOf(false) }

    val database = FirebaseDatabase.getInstance()
    val motoristasRef = database.reference.child("motorista")

    LaunchedEffect(Unit) {
        delay(100)
        animarImagem = true
        delay(400)
        animarTextos = true
        delay(300)
        animarIconesTopo = true
        delay(600)
        animarCampos = true
    }

    val screenHeight = LocalConfiguration.current.screenHeightDp.dp
    val density = LocalDensity.current
    val offsetY = with(density) { (screenHeight * 0.575f).roundToPx() }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Parte Azul (65%)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.65f)
                    .background(UFRPE_Blue)
                    .padding(horizontal = 16.dp, vertical = 24.dp),
            ) {
                androidx.compose.animation.AnimatedVisibility(
                    visible = animarIconesTopo,
                    enter = fadeIn(tween(1200)),
                    modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter).padding(top = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        LoginIconWithLabel(Icons.Outlined.ContactPage, "Sobre nós") { showSobreNosDialog = true }
                        LoginIconWithLabel(Icons.Outlined.Phone, "Contatos") { showContatosDialog = true }
                    }
                }

                Column(modifier = Modifier.fillMaxSize().padding(top = 65.dp)) {
                    androidx.compose.animation.AnimatedVisibility(
                        visible = animarImagem,
                        enter = fadeIn(tween(1500)) + scaleIn(initialScale = 0.9f, animationSpec = tween(1500))
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.imagem_motorista),
                            contentDescription = null,
                            modifier = Modifier.fillMaxWidth().height(180.dp).padding(top = 10.dp)
                        )
                    }

                    androidx.compose.animation.AnimatedVisibility(
                        visible = animarTextos,
                        enter = fadeIn(tween(1200)) + slideInVertically(tween(1200)) { it / 3 }
                    ) {
                        Column {
                            Text(text = "Login do motorista", fontSize = 24.sp, fontFamily = customFont, color = Color.White)
                            HorizontalDivider(
                                color = UFRPE_Yellow, // Amarelo oficial
                                thickness = 2.dp,
                                modifier = Modifier.fillMaxWidth(0.76f).padding(vertical = 12.dp)
                            )
                            Text(text = "Bem-vindo!", fontSize = 16.sp, color = Color.White, fontFamily = customFont)
                        }
                    }
                }
            }

            // Parte Branca (35%)
            Box(modifier = Modifier.fillMaxWidth().weight(0.35f).background(Color.White)) {
                androidx.compose.animation.AnimatedVisibility(
                    visible = animarCampos,
                    enter = fadeIn(tween(1200)) + slideInVertically(tween(1000)) { 20 },
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 20.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        OutlinedTextField(
                            value = username,
                            onValueChange = { if (it.matches(Regex("^[a-zA-Z0-9]*$"))) username = it },
                            label = { Text("Usuário", fontFamily = customFont) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = UFRPE_Blue,
                                unfocusedBorderColor = UFRPE_Blue,
                                focusedLabelColor = UFRPE_Blue
                            )
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it },
                            label = { Text("Senha", fontFamily = customFont) },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = UFRPE_Blue,
                                unfocusedBorderColor = UFRPE_Blue,
                                focusedLabelColor = UFRPE_Blue
                            )
                        )

                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = lembrarSenha, onCheckedChange = { lembrarSenha = it }, colors = CheckboxDefaults.colors(checkedColor = UFRPE_Blue))
                            Text("Lembrar-me", color = UFRPE_Blue, fontSize = 14.sp, fontFamily = customFont)
                        }

                        if (loginError) {
                            Text("Dados incorretos", color = Color.Red, fontSize = 12.sp, fontFamily = customFont)
                            Spacer(modifier = Modifier.height(4.dp))
                        }

                        Row(modifier = Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            // Botão Voltar (Estilo Secundário)
                            Button(
                                onClick = { navController.navigate("userSelection") },
                                modifier = Modifier.weight(1f).height(48.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Light_Gray_Darker)
                            ) {
                                Text("VOLTAR", color = UFRPE_Blue, fontWeight = FontWeight.Bold, fontFamily = customFont)
                            }

                            // Botão Entrar (Estilo Primário)
                            Button(
                                onClick = {
                                    motoristasRef.child(username).get().addOnSuccessListener { snapshot ->
                                        if (snapshot.child("senha").getValue<String>() == password) {
                                            navController.navigate("motoristaOptions")
                                        } else { loginError = true }
                                    }.addOnFailureListener { loginError = true }
                                },
                                modifier = Modifier.weight(1f).height(48.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = UFRPE_Blue)
                            ) {
                                Text("ENTRAR", color = Color.White, fontWeight = FontWeight.Bold, fontFamily = customFont)
                            }
                        }
                    }
                }
            }
        }

        // --- BARRA CENTRAL ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(screenHeight * 0.08f)
                .offset { IntOffset(0, offsetY) }
                .background(UFRPE_Blue)
        ) {
            Button(
                onClick = { selectedOption = "Aluno"; navController.navigate("AlunoScreen") },
                modifier = Modifier.weight(1f).fillMaxHeight(),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                shape = RoundedCornerShape(0.dp)
            ) {
                Text("Aluno", color = Color.White, fontFamily = customFont)
            }

            Box(Modifier.width(1.dp).fillMaxHeight().background(Color.White.copy(alpha = 0.5f)))

            Button(
                onClick = { },
                modifier = Modifier.weight(1f).fillMaxHeight(),
                colors = ButtonDefaults.buttonColors(containerColor = Light_Gray_Darker),
                shape = RoundedCornerShape(0.dp)
            ) {
                Text("Motorista", color = UFRPE_Blue, fontFamily = customFont)
            }
        }
    }


    // Dialogos
    if (showSobreNosDialog) {
        AlertDialog(
            onDismissRequest = { showSobreNosDialog = false },
            confirmButton = { TextButton(onClick = { showSobreNosDialog = false }) { Text("Fechar") } },
            title = { Text("Sobre") },
            text = { Text(
                fontSize = 14.sp,
                fontFamily = com.example.CirculAPP.ui.customFont,
                text = "Este aplicativo foi desenvolvido com dedicação por Emanuel Barbosa e Matheus, estudantes da Universidade Federal Rural de Pernambuco (UFRPE), com o objetivo de facilitar a mobilidade no campus e fortalecer a comunicação entre alunos e motoristas. 🎓\n\n" +
                        "👨‍💻 Desenvolvedores\n" +
                        "• Emanuel Barbosa\n" +
                        "\t📸 Instagram: @EmanuelB87_\n" +
                        "\t💻 GitHub: Emanuel-dev-Silva\n\n" ) }
        )
    }

    if (showContatosDialog) {
        AlertDialog(
            onDismissRequest = { showContatosDialog = false },
            confirmButton = { TextButton(onClick = { showContatosDialog = false }) { Text("Fechar") } },
            title = { Text("Contatos") },
            text = { Text(
                text = """
📍 DELOGS – Departamento de Logística e Serviços
• Diretoria: diretoria.delogs@ufrpe.br
• Resíduos laboratoriais: davv.delogs@ufrpe.br
• Segurança Universitária (DSU): seguranca.delogs@ufrpe.br
• Instagram: @ufrpedelogs

📍 Outros Setores da UFRPE
• Ouvidoria: ouvidoria@ufrpe.br
• Comunicação (Ascom): comunicacao@ufrpe.br
• Secretaria Geral: secretaria.geral@ufrpe.br
• Tecnologia da Informação (STI): sti@ufrpe.br
• Instagram oficial: @ufrpeoficial
""".trimIndent(),
                fontSize = 14.sp,
                fontFamily = customFont,
                color = Color.Black,
                modifier = Modifier.fillMaxWidth()
            ) }
        )
    }
}