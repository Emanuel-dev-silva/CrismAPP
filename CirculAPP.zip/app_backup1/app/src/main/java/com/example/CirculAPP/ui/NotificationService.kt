package com.example.CirculAPP

import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import android.app.NotificationManager
import com.google.firebase.database.*

class NotificationService : Service() {

    private val database = FirebaseDatabase.getInstance()
    private val motoristaRef = database.getReference("motorista/localizacao")
    private var lastStatus: String? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)

        // O vigia só trabalha se o Switch estiver ligado
        motoristaRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val notificacaoAtivada = prefs.getBoolean("notificacaoAtivada", false)

                if (!notificacaoAtivada) {
                    stopSelf() // Se desligou o switch, o serviço se mata
                    return
                }

                val status = snapshot.child("status").getValue(String::class.java)

                // Lógica simples: Notifica se mudar para "em rota"
                if (status == "em rota" && lastStatus != "em rota") {
                    sendNotification("🚍 O Circular iniciou a rota!")
                }
                lastStatus = status
            }
            override fun onCancelled(error: DatabaseError) {}
        })

        return START_STICKY // Faz o Android reabrir o vigia se ele for morto por falta de memória
    }

    private fun sendNotification(message: String) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val builder = NotificationCompat.Builder(this, "circulapp_notifications")
            .setSmallIcon(R.drawable.imagem)
            .setContentTitle("Info. Circular")
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)

        notificationManager.notify(1, builder.build())
    }

    override fun onBind(intent: Intent?): IBinder? = null
}