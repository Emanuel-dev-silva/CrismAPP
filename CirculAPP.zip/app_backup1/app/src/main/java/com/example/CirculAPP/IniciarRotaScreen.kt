package com.example.CirculAPP.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBackIosNew
import androidx.compose.material.icons.outlined.ContactPage
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.CirculAPP.R
import kotlinx.coroutines.delay

@Composable
fun IniciarRotaScreen(navController: NavController) {
    var selectedTime by remember { mutableStateOf("") }
    var showSobreNosDialog by remember { mutableStateOf(false) }
    var showContatosDialog by remember { mutableStateOf(false) }

    var animarImagem by remember { mutableStateOf(false) }
    var animarTextos by remember { mutableStateOf(false) }
    var animarBotoes by remember { mutableStateOf(false) }
    var animarIconesTopo by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        delay(100)
        animarImagem = true
        delay(400)
        animarTextos = true
        delay(300)
        animarIconesTopo = true
        delay(600)
        animarBotoes = true
    }

    val screenHeight = LocalConfiguration.current.screenHeightDp.dp
    val density = LocalDensity.current
    val offsetYHorarios = with(density) { (screenHeight * 0.575f).roundToPx() }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {

            // --- PARTE AZUL (65%) ---
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.65f)
                    .background(Color(0xFF004AAD))
                    .padding(horizontal = 16.dp, vertical = 24.dp)
            ) {
                // Icones Topo
                androidx.compose.animation.AnimatedVisibility(
                    visible = animarIconesTopo,
                    enter = fadeIn(tween(1200)),
                    modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter).padding(top = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        IconWithLabel(Icons.Outlined.ContactPage, "Sobre nós") { showSobreNosDialog = true }
                        IconWithLabel(Icons.Outlined.Phone, "Contatos") { showContatosDialog = true }
                    }
                }

                Column(
                    modifier = Modifier.fillMaxSize().padding(top = 65.dp),
                    verticalArrangement = Arrangement.Top
                ) {
                    androidx.compose.animation.AnimatedVisibility(
                        visible = animarImagem,
                        enter = fadeIn(tween(1500)) + scaleIn(initialScale = 0.92f, animationSpec = tween(1200)),
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.imagem_inicio_rota),
                            contentDescription = "Imagem ilustrativa",
                            modifier = Modifier.fillMaxWidth().height(180.dp)
                        )
                    }

                    androidx.compose.animation.AnimatedVisibility(
                        visible = animarTextos,
                        enter = fadeIn(tween(1200)) + slideInVertically(tween(1200)) { it / 3 }
                    ) {
                        Column {
                            Text(
                                text = "\nBem-vindo",
                                fontSize = 24.sp,
                                fontFamily = customFont,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            HorizontalDivider(
                                color = Color(0xFFFFD700),
                                thickness = 2.dp,
                                modifier = Modifier.fillMaxWidth(0.7f).padding(vertical = 12.dp)
                            )
                            Text(
                                text = "Selecione a rota que deseja iniciar:",
                                fontSize = 16.sp,
                                fontFamily = customFont,
                                color = Color.White
                            )
                        }
                    }
                }
            }

            // --- PARTE BRANCA (35%) ---
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.35f)
                    .background(Color.White),
                contentAlignment = Alignment.BottomCenter
            ) {
                androidx.compose.animation.AnimatedVisibility(
                    visible = animarBotoes,
                    enter = fadeIn(tween(1000)) + slideInVertically { 40 },
                    modifier = Modifier.padding(bottom = 110.dp)
                ) {
                    // BOTÃO VOLTAR (Padrão Sair do APP)
                    Surface(
                        onClick = { navController.navigate("motoristaOptions") },
                        modifier = Modifier
                            .height(48.dp)
                            .fillMaxWidth(0.65f),
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFE0E0E0), // Light_Gray_Darker
                        shadowElevation = 2.dp
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxSize()
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .width(40.dp)
                                    .background(Color(0xFFFFD700)), // UFRPE_Yellow
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.ArrowBackIosNew,
                                    contentDescription = null,
                                    tint = Color(0xFF004AAD), // UFRPE_Blue
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Text(
                                text = "Voltar",
                                color = Color(0xFF004AAD), // UFRPE_Blue
                                fontSize = 14.sp,
                                fontFamily = customFont,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }

        // --- BARRA DE SELEÇÃO CENTRALIZADA (FORA DA COLUMN PARA FLUTUAR) ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(screenHeight * 0.08f)
                .offset { IntOffset(0, offsetYHorarios) }
                .background(Color(0xFF004AAD))
        ) {
            val horarios = listOf("7h às 19h", "19h às 22h")
            horarios.forEachIndexed { index, horario ->
                Button(
                    onClick = {
                        selectedTime = horario
                        navController.navigate("mapsMotorista/$horario")
                    },
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedTime == horario) Color(0xFFE0E0E0) else Color.Transparent
                    ),
                    shape = RoundedCornerShape(0.dp)
                ) {
                    Text(
                        horario,
                        color = if (selectedTime == horario) Color(0xFF004AAD) else Color.White,
                        fontFamily = customFont,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.alpha(if (animarBotoes) 1f else 0f)
                    )
                }
                if (index == 0) Box(Modifier.width(1.dp).fillMaxHeight().background(Color.White.copy(alpha = 0.5f)))
            }
        }
    }

                // -------------------- DIÁLOGOS DE INFORMAÇÃO --------------------
                if (showSobreNosDialog) {
                    AlertDialog(
                        onDismissRequest = { showSobreNosDialog = false },
                        confirmButton = {
                            TextButton(onClick = { showSobreNosDialog = false }) {
                                Text("Fechar", fontSize = 16.sp, fontFamily = customFont)
                            }
                        },
                        title = { Text("🚌 Sobre o CirculAPP", fontSize = 24.sp) },
                        text = {
                            Text(
                                fontSize = 14.sp,
                                fontFamily = com.example.CirculAPP.ui.customFont,
                                text = "Este aplicativo foi desenvolvido com dedicação por Emanuel Barbosa e Matheus, estudantes da Universidade Federal Rural de Pernambuco (UFRPE), com o objetivo de facilitar a mobilidade no campus e fortalecer a comunicação entre alunos e motoristas. 🎓\n\n" +
                                        "👨‍💻 Desenvolvedores\n" +
                                        "• Emanuel Barbosa\n" +
                                        "\t📸 Instagram: @EmanuelB87_\n" +
                                        "\t💻 GitHub: Emanuel-dev-Silva\n\n"
                            )
                        }
                    )
                }

                if (showContatosDialog) {
                    AlertDialog(
                        onDismissRequest = { showContatosDialog = false },
                        confirmButton = {
                            TextButton(onClick = { showContatosDialog = false }) {
                                Text("Fechar", fontSize = 16.sp, fontFamily = customFont)
                            }
                        },
                        title = { Text("DELOGS/UFRPE", fontSize = 24.sp) },
                        text = {
                            Text(
                                text = """
📍 DELOGS – Departamento de Logística e Serviços
• Diretoria: diretoria.delogs@ufrpe.br
• Resíduos laboratoriais: davv.delogs@ufrpe.br
• Segurança Universitária (DSU): seguranca.delogs@ufrpe.br
• Instagram: @ufrpedelogs

📍 Outros Setores da UFRPE
• Ouvidoria: ouvidoria@ufrpe.br
• Comunicação (Ascom): comunicacao@ufrpe.br
• Secretaria Geral: secretaria.geral@ufrpe.br
• Tecnologia da Informação (STI): sti@ufrpe.br
• Instagram oficial: @ufrpeoficial
""".trimIndent(),
                                fontSize = 14.sp,
                                fontFamily = customFont,
                                color = Color.Black,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    )
                }
            }
