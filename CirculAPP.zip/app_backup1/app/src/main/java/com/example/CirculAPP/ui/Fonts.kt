package com.example.CirculAPP.ui

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import com.example.CirculAPP.R

val customFont = FontFamily(Font(R.font.sam_font1))