package com.example.CirculAPP.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForwardIos
import androidx.compose.material.icons.outlined.ArrowBackIosNew
import androidx.compose.material.icons.outlined.ContactPage
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.CirculAPP.R
import kotlinx.coroutines.delay

private val UFRPE_Blue = Color(0xFF004AAD)
private val UFRPE_Yellow = Color(0xFFFFD700)
private val Light_Gray_Darker = Color(0xFFE0E0E0)

@Composable
fun ItinerarioIconWithLabel(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .padding(top = 8.dp)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(imageVector = icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(28.dp))
        Text(text = label, color = Color.White, fontSize = 12.sp, textAlign = TextAlign.Center, fontFamily = customFont)
    }
}

@Composable
fun ItinerarioScreen(navController: NavHostController) {
    var selectedOption by remember { mutableStateOf("Aluno") }
    var showSobreNosDialog by remember { mutableStateOf(false) }
    var showContatosDialog by remember { mutableStateOf(false) }

    var animarMapa by remember { mutableStateOf(false) }
    var animarTextos by remember { mutableStateOf(false) }
    var animarBotoes by remember { mutableStateOf(false) }
    var animarIconesTopo by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        delay(100)
        animarMapa = true
        delay(400)
        animarTextos = true
        delay(300)
        animarIconesTopo = true
        delay(600)
        animarBotoes = true
    }

    val screenHeight = LocalConfiguration.current.screenHeightDp.dp
    val density = LocalDensity.current
    val offsetY = with(density) { (screenHeight * 0.575f).roundToPx() }

    Box(modifier = Modifier.fillMaxSize()) {
        // CONTEÚDO DE FUNDO (AZUL E BRANCO)
        Column(modifier = Modifier.fillMaxSize()) {
            // Parte Azul (65%)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.65f)
                    .background(UFRPE_Blue)
                    .padding(horizontal = 16.dp, vertical = 24.dp),
            ) {
                androidx.compose.animation.AnimatedVisibility(
                    visible = animarIconesTopo,
                    enter = fadeIn(tween(1200)),
                    modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter).padding(top = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        ItinerarioIconWithLabel(Icons.Outlined.ContactPage, "Sobre nós") { showSobreNosDialog = true }
                        ItinerarioIconWithLabel(Icons.Outlined.Phone, "Contatos") { showContatosDialog = true }
                    }
                }

                Column(
                    modifier = Modifier.fillMaxSize().padding(top = 65.dp),
                    verticalArrangement = Arrangement.Top
                ) {
                    androidx.compose.animation.AnimatedVisibility(
                        visible = animarMapa,
                        enter = fadeIn(tween(1500)) + scaleIn(initialScale = 0.95f, animationSpec = tween(1200))
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.itinerarioate19),
                            contentDescription = "Mapa",
                            modifier = Modifier.fillMaxWidth().height(220.dp).padding(bottom = 8.dp)
                        )
                    }

                    androidx.compose.animation.AnimatedVisibility(
                        visible = animarTextos,
                        enter = fadeIn(tween(1200)) + slideInVertically(tween(1200)) { it / 3 }
                    ) {
                        Column {
                            Text("Mapa do itinerário", fontSize = 24.sp, fontFamily = customFont, color = Color.White)
                            HorizontalDivider(modifier = Modifier.fillMaxWidth(0.7f).padding(vertical = 12.dp), thickness = 2.dp, color = UFRPE_Yellow)
                            Text("Horário de Operação:\n🕒 07:00 - 19:00", style = TextStyle(fontSize = 16.sp, fontFamily = customFont), color = Color.White)
                        }
                    }
                }
            }

            // Parte Branca (35%)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.35f)
                    .background(Color.White)
            ) {
                androidx.compose.animation.AnimatedVisibility(
                    visible = animarBotoes,
                    enter = fadeIn(tween(1200)) + slideInVertically(tween(1000)) { 20 },
                    modifier = Modifier.fillMaxSize()
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxSize().padding(top = 10.dp)
                    ) {
                        // BOTÃO REDUZIDO LATERALMENTE (Igual ao Sair)
                        Surface(
                            onClick = { navController.navigate("aposAs19hScreen") },
                            modifier = Modifier.height(52.dp).fillMaxWidth(0.65f),
                            color = Light_Gray_Darker,
                            shape = RoundedCornerShape(12.dp),
                            shadowElevation = 4.dp
                        ) {
                            Row(modifier = Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.fillMaxHeight().width(45.dp).background(UFRPE_Yellow), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Filled.ArrowForwardIos, null, tint = UFRPE_Blue, modifier = Modifier.size(18.dp))
                                }
                                Text(text = "Após às 19h", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, color = UFRPE_Blue, fontWeight = FontWeight.Bold, fontFamily = customFont, fontSize = 15.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        TextButton(onClick = { navController.popBackStack() }, modifier = Modifier.height(40.dp)) {
                            Icon(Icons.Outlined.ArrowBackIosNew, null, modifier = Modifier.size(14.dp), tint = UFRPE_Blue)
                            Spacer(Modifier.width(8.dp))
                            Text("Voltar ao Menu", color = UFRPE_Blue, fontSize = 15.sp, fontFamily = customFont)
                        }
                    }
                }
            }
        }

        // BARRA CENTRAL (FORA DA COLUMN PRINCIPAL PARA NÃO SUMIR)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(screenHeight * 0.08f)
                .offset { IntOffset(0, offsetY) }
                .background(UFRPE_Blue)
        ) {
            Button(
                onClick = { selectedOption = "Aluno" },
                modifier = Modifier.weight(1f).fillMaxHeight(),
                colors = ButtonDefaults.buttonColors(containerColor = if (selectedOption == "Aluno") Light_Gray_Darker else Color.Transparent),
                shape = RoundedCornerShape(0.dp)
            ) {
                Text("Aluno", color = if (selectedOption == "Aluno") UFRPE_Blue else Color.White, fontFamily = customFont)
            }
            Box(Modifier.width(1.dp).fillMaxHeight().background(Color.White.copy(alpha = 0.5f)))
            Button(
                onClick = {
                    selectedOption = "Motorista"
                    navController.navigate("motoristaLogin")
                },
                modifier = Modifier.weight(1f).fillMaxHeight(),
                colors = ButtonDefaults.buttonColors(containerColor = if (selectedOption == "Motorista") Light_Gray_Darker else Color.Transparent),
                shape = RoundedCornerShape(0.dp)
            ) {
                Text("Motorista", color = if (selectedOption == "Motorista") UFRPE_Blue else Color.White, fontFamily = customFont)
            }
        }

        // Diálogos
        if (showSobreNosDialog) {
            AlertDialog(
                onDismissRequest = { showSobreNosDialog = false },
                confirmButton = { TextButton(onClick = { showSobreNosDialog = false }) { Text("Fechar") } },
                title = { Text("Sobre o CirculAPP") },
                text = { Text(
                    fontSize = 14.sp,
                    fontFamily = com.example.CirculAPP.ui.customFont,
                    text = "Este aplicativo foi desenvolvido com dedicação por Emanuel Barbosa e Matheus, estudantes da Universidade Federal Rural de Pernambuco (UFRPE), com o objetivo de facilitar a mobilidade no campus e fortalecer a comunicação entre alunos e motoristas. 🎓\n\n" +
                            "👨‍💻 Desenvolvedores\n" +
                            "• Emanuel Barbosa\n" +
                            "\t📸 Instagram: @EmanuelB87_\n" +
                            "\t💻 GitHub: Emanuel-dev-Silva\n\n" ) }
            )
        }
        if (showContatosDialog) {
            AlertDialog(
                onDismissRequest = { showContatosDialog = false },
                confirmButton = { TextButton(onClick = { showContatosDialog = false }) { Text("Fechar") } },
                title = { Text("Contatos") },
                text = { Text(
                    text = """
📍 DELOGS – Departamento de Logística e Serviços
• Diretoria: diretoria.delogs@ufrpe.br
• Resíduos laboratoriais: davv.delogs@ufrpe.br
• Segurança Universitária (DSU): seguranca.delogs@ufrpe.br
• Instagram: @ufrpedelogs

📍 Outros Setores da UFRPE
• Ouvidoria: ouvidoria@ufrpe.br
• Comunicação (Ascom): comunicacao@ufrpe.br
• Secretaria Geral: secretaria.geral@ufrpe.br
• Tecnologia da Informação (STI): sti@ufrpe.br
• Instagram oficial: @ufrpeoficial
""".trimIndent(),
                    fontSize = 14.sp,
                    fontFamily = customFont,
                    color = Color.Black,
                    modifier = Modifier.fillMaxWidth()
                ) }
            )
        }
    }
}