package com.example.CirculAPP.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.SyncAlt
import androidx.compose.material.icons.outlined.ArrowBackIosNew
import androidx.compose.material.icons.outlined.ContactPage
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.navigation.NavController
import com.example.CirculAPP.R
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun InformarParadaScreen(navController: NavController) {
    val databaseRef = FirebaseDatabase.getInstance().getReference("motorista/localizacao")

    var selecionouParada by remember { mutableStateOf(false) }
    var tempoRestante by remember { mutableStateOf(10) }
    var selectedOption by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    var showSobreNosDialog by remember { mutableStateOf(false) }
    var showContatosDialog by remember { mutableStateOf(false) }

    // Estados de animação
    var animarImagem by remember { mutableStateOf(false) }
    var animarTextos by remember { mutableStateOf(false) }
    var animarBotoes by remember { mutableStateOf(false) }
    var animarIconesTopo by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        delay(100)
        animarImagem = true
        delay(400)
        animarTextos = true
        delay(300)
        animarIconesTopo = true
        delay(600)
        animarBotoes = true
    }

    val screenHeight = LocalConfiguration.current.screenHeightDp.dp
    val density = LocalDensity.current
    val offsetYParadas = with(density) { (screenHeight * 0.575f).roundToPx() }
    val offsetYTexto = with(density) { (screenHeight * 0.49f).roundToPx() }

    fun selecionarParada(parada: String) {
        selecionouParada = true
        tempoRestante = 10
        databaseRef.setValue(
            mapOf(
                "latitude" to null,
                "longitude" to null,
                "status" to "parado",
                "parada" to parada
            )
        )
        scope.launch {
            while (tempoRestante > 0) {
                delay(1000L)
                tempoRestante--
            }
            selecionouParada = false
            selectedOption = ""
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {

            // PARTE SUPERIOR AZUL
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.65f)
                    .background(Color(0xFF004AAD))
                    .padding(horizontal = 16.dp, vertical = 24.dp)
            ) {
                // Ícones do Topo (Camada Superior)
                androidx.compose.animation.AnimatedVisibility(
                    visible = animarIconesTopo,
                    enter = fadeIn(tween(1200)),
                    modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter)
                        .padding(top = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        IconWithLabel(
                            Icons.Outlined.ContactPage,
                            "Sobre nós"
                        ) { showSobreNosDialog = true }
                        IconWithLabel(Icons.Outlined.Phone, "Contatos") {
                            showContatosDialog = true
                        }
                    }
                }

                // Conteúdo Principal
                Column(
                    modifier = Modifier.fillMaxSize().padding(top = 65.dp),
                    verticalArrangement = Arrangement.Top,
                    horizontalAlignment = Alignment.Start
                ) {
                    androidx.compose.animation.AnimatedVisibility(
                        visible = animarImagem,
                        enter = fadeIn(tween(1500)) + scaleIn(
                            initialScale = 0.92f,
                            animationSpec = tween(1200)
                        )
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.imagem_parada),
                            contentDescription = "Imagem ilustrativa",
                            modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
                        )
                    }

                    androidx.compose.animation.AnimatedVisibility(
                        visible = animarTextos,
                        enter = fadeIn(tween(1200)) + slideInVertically(tween(1200)) { it / 3 }
                    ) {
                        Column {
                            Text(
                                text = "\nBem-vindo",
                                fontSize = 24.sp,
                                fontFamily = customFont,
                                color = Color.White
                            )
                            HorizontalDivider(
                                color = Color.White,
                                thickness = 2.dp,
                                modifier = Modifier.fillMaxWidth(0.76f).padding(vertical = 16.dp)
                            )
                            Text(
                                text = "Qual o motivo da parada?",
                                style = TextStyle(fontSize = 16.sp, fontFamily = customFont),
                                color = Color.White
                            )
                        }
                    }
                }
            }

            // PARTE INFERIOR BRANCA
            Box(modifier = Modifier.fillMaxWidth().weight(0.35f).background(Color.White))
        }

        // BOTÕES DE PARADA (Barra Central)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(screenHeight * 0.08f)
                .offset { IntOffset(0, offsetYParadas) },
            verticalAlignment = Alignment.CenterVertically
        ) {
            val botoes = listOf(
                Triple("Abastecimento", Icons.Default.LocalGasStation, "Abastecimento"),
                Triple("Troca de turno", Icons.Default.SyncAlt, "Troca de turno"),
                Triple("Refeição", Icons.Default.Restaurant, "Refeição")
            )

            botoes.forEachIndexed { index, (label, icon, value) ->
                val isSelected = selectedOption == value
                val isDisabled = selecionouParada && !isSelected

                Button(
                    onClick = {
                        selectedOption = value
                        selecionarParada(value)
                    },
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                    shape = RoundedCornerShape(0.dp),
                    enabled = !selecionouParada || isSelected,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = when {
                            isSelected -> Color(0xFFE3E3E3)
                            isDisabled -> Color(0xFF002B66)
                            else -> Color(0xFF004AAD)
                        }
                    )
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = if (isSelected) Color(0xFF004AAD) else Color.White,
                        modifier = Modifier.size(28.dp).alpha(if (animarIconesTopo) 1f else 0f)
                    )
                }

                if (index < botoes.lastIndex) {
                    Box(Modifier.width(2.dp).fillMaxHeight().background(Color.White))
                }
            }
        }

        // TEXTO AGUARDE
        if (selecionouParada) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp)
                    .offset { IntOffset(0, offsetYTexto) },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Aguarde $tempoRestante segundos para iniciar a rota ou informar outra parada...",
                    color = Color(0xFF004AAD),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    fontFamily = customFont
                )
            }
        }

        // BOTÃO VOLTAR (Baseado no padrão "Sair do APP")
        androidx.compose.animation.AnimatedVisibility(
            visible = animarBotoes,
            enter = fadeIn(tween(1000)) + slideInVertically { 40 },
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            Surface(
                onClick = { navController.navigate("motoristaOptions") },
                modifier = Modifier
                    .padding(bottom = 110.dp) // Alinhado com o padrão da UserSelectionScreen
                    .height(48.dp)
                    .fillMaxWidth(0.65f),
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFFE0E0E0), // Light_Gray_Darker
                shadowElevation = 2.dp
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxSize()
                ) {
                    // Detalhe Amarelo lateral com o ícone
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .width(40.dp)
                            .background(Color(0xFFFFD700)), // UFRPE_Yellow
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ArrowBackIosNew,
                            contentDescription = null,
                            tint = Color(0xFF004AAD), // UFRPE_Blue
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Text(
                        text = "Voltar",
                        color = Color(0xFF004AAD), // UFRPE_Blue
                        fontSize = 14.sp,
                        fontFamily = customFont,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        }

        // DIÁLOGOS (Sobre nós e Contatos)
        if (showSobreNosDialog) {
            AlertDialog(
                onDismissRequest = { showSobreNosDialog = false },
                confirmButton = {
                    TextButton(onClick = {
                        showSobreNosDialog = false
                    }) { Text("Fechar", fontFamily = customFont) }
                },
                title = { Text("🚌 Sobre o CirculAPP", fontSize = 24.sp) },
                text = {
                    Text(
                        fontSize = 14.sp,
                        fontFamily = com.example.CirculAPP.ui.customFont,
                        text = "Este aplicativo foi desenvolvido com dedicação por Emanuel Barbosa e Matheus, estudantes da Universidade Federal Rural de Pernambuco (UFRPE), com o objetivo de facilitar a mobilidade no campus e fortalecer a comunicação entre alunos e motoristas. 🎓\n\n" +
                                "👨‍💻 Desenvolvedores\n" +
                                "• Emanuel Barbosa\n" +
                                "\t📸 Instagram: @EmanuelB87_\n" +
                                "\t💻 GitHub: Emanuel-dev-Silva\n\n"
                    )
                }
            )
        }
        if (showContatosDialog) {
            AlertDialog(
                onDismissRequest = { showContatosDialog = false },
                confirmButton = {
                    TextButton(onClick = {
                        showContatosDialog = false
                    }) { Text("Fechar", fontFamily = customFont) }
                },
                title = { Text("DELOGS/UFRPE", fontSize = 24.sp) },
                text = {
                    Text(
                        text = """
📍 DELOGS – Departamento de Logística e Serviços
• Diretoria: diretoria.delogs@ufrpe.br
• Resíduos laboratoriais: davv.delogs@ufrpe.br
• Segurança Universitária (DSU): seguranca.delogs@ufrpe.br
• Instagram: @ufrpedelogs

📍 Outros Setores da UFRPE
• Ouvidoria: ouvidoria@ufrpe.br
• Comunicação (Ascom): comunicacao@ufrpe.br
• Secretaria Geral: secretaria.geral@ufrpe.br
• Tecnologia da Informação (STI): sti@ufrpe.br
• Instagram oficial: @ufrpeoficial
""".trimIndent(),
                        fontSize = 14.sp,
                        fontFamily = customFont,
                        color = Color.Black,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            )
        }
    }
}