package com.example.CirculAPP.ui

import android.app.Activity
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.outlined.ContactPage
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.CirculAPP.R
import kotlinx.coroutines.delay

// cores usadas
private val UFRPE_Blue = Color(0xFF004AAD)
private val UFRPE_Yellow = Color(0xFFFFD700)
private val Light_Gray_Darker = Color(0xFFE0E0E0)

@Composable
fun UserIconWithLabel(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(imageVector = icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(28.dp))
        Text(text = label, color = Color.White, fontSize = 12.sp, fontFamily = customFont)
    }
}

@Composable
fun UserSelectionScreen(onAlunoSelected: () -> Unit, onMotoristaSelected: () -> Unit) {
    val context = LocalContext.current
    val configuration = LocalConfiguration.current
    val screenHeight = configuration.screenHeightDp.dp

    var selectedOption by remember { mutableStateOf("") }
    var showSobreNosDialog by remember { mutableStateOf(false) }
    var showContatosDialog by remember { mutableStateOf(false) }

    // animações usadas
    var animarImagem by remember { mutableStateOf(false) }
    var animarTextosSuperior by remember { mutableStateOf(false) }
    var animarLabelsBotoes by remember { mutableStateOf(false) }
    var animarBotaoSair by remember { mutableStateOf(false) }
    var animarIconesTopo by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        delay(100)
        animarImagem = true
        animarBotaoSair = true
        delay(300)
        animarTextosSuperior = true
        delay(200)
        animarLabelsBotoes = true
        delay(200)
        animarIconesTopo = true
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {

            // area azul (65%)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.65f)
                    .background(UFRPE_Blue)
                    .padding(horizontal = 16.dp, vertical = 24.dp)
            ) {
                Column(modifier = Modifier.fillMaxSize()) {

                    // botões de cima
                    Box(modifier = Modifier.fillMaxWidth().height(70.dp)) {
                        androidx.compose.animation.AnimatedVisibility(
                            visible = animarIconesTopo,
                            enter = fadeIn(tween(800))
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                UserIconWithLabel(Icons.Outlined.ContactPage, "Sobre nós") { showSobreNosDialog = true }
                                UserIconWithLabel(Icons.Outlined.Phone, "Contatos") { showContatosDialog = true }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // imagem area azul
                    androidx.compose.animation.AnimatedVisibility(
                        visible = animarImagem,
                        enter = fadeIn(tween(1000)) + scaleIn(initialScale = 0.9f),
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.imagem),
                            contentDescription = null,
                            modifier = Modifier.fillMaxWidth().height(180.dp)
                        )
                    }

                    // texto area azul
                    androidx.compose.animation.AnimatedVisibility(
                        visible = animarTextosSuperior,
                        enter = fadeIn(tween(1000)) + slideInVertically { it / 4 }
                    ) {
                        Column {
                            Text("\nOlá, você é aluno ou motorista?", fontSize = 22.sp, color = Color.White, fontFamily = customFont, fontWeight = FontWeight.Bold)
                            HorizontalDivider(color = UFRPE_Yellow, thickness = 2.dp, modifier = Modifier.fillMaxWidth(0.7f).padding(vertical = 12.dp))
                            Text("Selecione uma opção para navegar no campus", fontSize = 16.sp, color = Color.White, fontFamily = customFont)
                        }
                    }
                }
            }

            // area branca (35%)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.35f)
                    .background(Color.White),
                contentAlignment = Alignment.BottomCenter
            ) {
                androidx.compose.animation.AnimatedVisibility(
                    visible = animarBotaoSair,
                    enter = fadeIn(tween(1000)) + slideInVertically { 40 }
                ) {
                    // botão sair do app
                    Surface(
                        onClick = { if (context is Activity) context.finish() },
                        modifier = Modifier
                            .padding(bottom = 110.dp)
                            .height(48.dp)
                            .fillMaxWidth(0.65f),
                        shape = RoundedCornerShape(12.dp),
                        color = Light_Gray_Darker,
                        shadowElevation = 2.dp
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxSize()
                        ) {
                            // coisinha amarelo do lado d o botão
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .width(40.dp)
                                    .background(UFRPE_Yellow),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.ExitToApp,
                                    contentDescription = null,
                                    tint = UFRPE_Blue,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            Text(
                                text = "Sair do APP",
                                color = UFRPE_Blue,
                                fontSize = 14.sp,
                                fontFamily = customFont,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }
            }
        }

        // --- BARRA CENTRAL (FLUTUANTE) ---
        val density = LocalDensity.current
        val offsetY = with(density) { (screenHeight * 0.575f).roundToPx() }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(screenHeight * 0.08f)
                .offset { IntOffset(0, offsetY) }
                .background(UFRPE_Blue)
        ) {
            Button(
                onClick = { selectedOption = "Aluno"; onAlunoSelected() },
                modifier = Modifier.weight(1f).fillMaxHeight(),
                colors = ButtonDefaults.buttonColors(containerColor = if (selectedOption == "Aluno") Color(0xFFE0E0E0) else Color.Transparent),
                shape = RoundedCornerShape(0.dp)
            ) {
                Text(
                    "Aluno",
                    color = if (selectedOption == "Aluno") UFRPE_Blue else Color.White,
                    fontFamily = customFont,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.alpha(if (animarLabelsBotoes) 1f else 0f)
                )
            }
            Box(Modifier.width(1.dp).fillMaxHeight().background(Color.White.copy(alpha = 0.3f)))
            Button(
                onClick = { selectedOption = "Motorista"; onMotoristaSelected() },
                modifier = Modifier.weight(1f).fillMaxHeight(),
                colors = ButtonDefaults.buttonColors(containerColor = if (selectedOption == "Motorista") Color(0xFFE0E0E0) else Color.Transparent),
                shape = RoundedCornerShape(0.dp)
            ) {
                Text(
                    "Motorista",
                    color = if (selectedOption == "Motorista") UFRPE_Blue else Color.White,
                    fontFamily = customFont,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.alpha(if (animarLabelsBotoes) 1f else 0f)
                )
            }
        }
    }

    // Diálogos de Alerta
    if (showSobreNosDialog) {
        AlertDialog(
            onDismissRequest = { showSobreNosDialog = false },
            confirmButton = { TextButton(onClick = { showSobreNosDialog = false }) { Text("Fechar") } },
            title = { Text("Sobre o CirculAPP", fontFamily = customFont) },
            text = { Text(
                fontSize = 14.sp,
                fontFamily = com.example.CirculAPP.ui.customFont,
                text = "Este aplicativo foi desenvolvido com dedicação por Emanuel Barbosa e Matheus, estudantes da Universidade Federal Rural de Pernambuco (UFRPE), com o objetivo de facilitar a mobilidade no campus e fortalecer a comunicação entre alunos e motoristas. 🎓\n\n" +
                        "👨‍💻 Desenvolvedores\n" +
                        "• Emanuel Barbosa\n" +
                        "\t📸 Instagram: @EmanuelB87_\n" +
                        "\t💻 GitHub: Emanuel-dev-Silva\n\n" ) }
        )
    }
    if (showContatosDialog) {
        AlertDialog(
            onDismissRequest = { showContatosDialog = false },
            confirmButton = { TextButton(onClick = { showContatosDialog = false }) { Text("Fechar") } },
            title = { Text("Contatos", fontFamily = customFont) },
            text = { Text(
                text = """
📍 DELOGS – Departamento de Logística e Serviços
• Diretoria: diretoria.delogs@ufrpe.br
• Resíduos laboratoriais: davv.delogs@ufrpe.br
• Segurança Universitária (DSU): seguranca.delogs@ufrpe.br
• Instagram: @ufrpedelogs

📍 Outros Setores da UFRPE
• Ouvidoria: ouvidoria@ufrpe.br
• Comunicação (Ascom): comunicacao@ufrpe.br
• Secretaria Geral: secretaria.geral@ufrpe.br
• Tecnologia da Informação (STI): sti@ufrpe.br
• Instagram oficial: @ufrpeoficial
""".trimIndent(),
                fontSize = 14.sp,
                fontFamily = customFont,
                color = Color.Black,
                modifier = Modifier.fillMaxWidth()
            ) }
        )
    }
}